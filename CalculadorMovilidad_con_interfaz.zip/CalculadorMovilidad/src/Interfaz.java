import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

public class Interfaz extends CalculadorMovilidad{
	
	public static void main(String[] args){
		
		CalculadorMovilidad op = new CalculadorMovilidad();
		
		JFrame marco = new JFrame();
		JPanel panel_estancia = new JPanel();
		JPanel panel_colectivo = new JPanel();
		JPanel panel_propuesta = new JPanel();
		JPanel panel_billete = new JPanel();
		
		JTextArea texto = new JTextArea();
		texto.setPreferredSize(new Dimension(190,60));
		texto.setOpaque(false);
		texto.setEditable(false);
		texto.setLineWrap(true);
		
		texto.setBorder(BorderFactory.createCompoundBorder(
			   BorderFactory.createLoweredBevelBorder(),
			   BorderFactory.createEmptyBorder(5, 5, 5, 5)
		));
		
		
		JLabel labl2 = new JLabel("Días ");
		JSpinner spinner = new JSpinner(new SpinnerNumberModel(1,1,999,1));
		Dimension dimension = new Dimension(45,20);
		spinner.setPreferredSize(dimension);
		
		JSlider slider = new JSlider(0, 100, 1);
		
		slider.setPaintTrack(true);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setMajorTickSpacing(20);
		slider.setMinorTickSpacing(5);
		
		panel_estancia.setLayout(new FlowLayout(1,1,20));
		panel_colectivo.setLayout(new GridLayout(6,1,1,15));
		panel_propuesta.setLayout(new FlowLayout(1,6,20));
		
		panel_estancia.setBorder(BorderFactory.createCompoundBorder(
			   BorderFactory.createTitledBorder("Estancia"),
			   BorderFactory.createEmptyBorder(0, 10, 5, 1)
		));
		
		panel_estancia.add(labl2);
		panel_estancia.add(spinner);
		panel_estancia.add(slider);
		
		JLabel labl = new JLabel("Viajes: 1");
		panel_estancia.add(labl);
		
		slider.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent event) {
				labl.setText("Viajes: " + slider.getValue());
			}
		});
		
		panel_colectivo.setBorder(BorderFactory.createCompoundBorder(
			   BorderFactory.createTitledBorder("Colectivo"),
			   BorderFactory.createEmptyBorder(10, 2, 1, 76)
		));
		
		ButtonGroup grupo_botones = new ButtonGroup();
		
		JRadioButton sin_descuento = new JRadioButton("Sin Descuento");
		JRadioButton jubilado = new JRadioButton("Jubilado");
		JRadioButton discapacitado = new JRadioButton("Discapacitado");
		JRadioButton parado = new JRadioButton("Parado");
		JRadioButton estudiante = new JRadioButton("Estudiante");
		
		grupo_botones.add(sin_descuento);
		grupo_botones.add(jubilado);
		grupo_botones.add(discapacitado);
		grupo_botones.add(parado);
		grupo_botones.add(estudiante);
		
		sin_descuento.doClick();
		panel_colectivo.add(sin_descuento);
		panel_colectivo.add(jubilado);
		panel_colectivo.add(discapacitado);
		panel_colectivo.add(parado);
		panel_colectivo.add(estudiante);
		
		panel_propuesta.setBorder(BorderFactory.createCompoundBorder(
			   BorderFactory.createTitledBorder("Propuesta"),
			   BorderFactory.createEmptyBorder(1, 20, 10, 10)
		));
		
		panel_propuesta.add(texto);
		
		Icon imagen_verde = new ImageIcon("src/Imagenes/valBot.png");
		Icon imagen_roja = new ImageIcon("src/Imagenes/canBot.png");
		
		JButton boton_verde = new JButton(imagen_verde);
		JButton boton_rojo = new JButton(imagen_roja);
		
		panel_propuesta.add(boton_verde);
		panel_propuesta.add(boton_rojo);
		
		panel_billete.setBorder(BorderFactory.createCompoundBorder(
			   BorderFactory.createTitledBorder("Su Billete"),
			   BorderFactory.createEmptyBorder(1, 20, 10, 10)
		));
		
		JLabel discapacitado1 = new JLabel(new ImageIcon("src/Imagenes/Discapacitado/Discapacitado_1_Viaje.png"));
		JLabel discapacitado7 = new JLabel(new ImageIcon("src/Imagenes/Discapacitado/Discapacitado_7_Viaje.png"));
		JLabel discapacitado30 = new JLabel(new ImageIcon("src/Imagenes/Discapacitado/Discapacitado_30_Viaje.png"));

		JLabel estudiante1 = new JLabel(new ImageIcon("src/Imagenes/Estudiante/Estudiante_1_Viaje.jpg"));
		JLabel estudiante7 = new JLabel(new ImageIcon("src/Imagenes/Estudiante/Estudiante_7_Viaje.jpg"));
		JLabel estudiante30 = new JLabel(new ImageIcon("src/Imagenes/Estudiante/Estudiante_30_Viaje.jpg"));

		JLabel jubilado1 = new JLabel(new ImageIcon("src/Imagenes/Jubilados/Jubilados_1_Viaje.png"));
		JLabel jubilado7 = new JLabel(new ImageIcon("src/Imagenes/Jubilados/Jubilados_7_Viaje.png"));
		JLabel jubilado30 = new JLabel(new ImageIcon("src/Imagenes/Jubilados/Jubilados_30_Viaje.png"));

		JLabel parado1 = new JLabel(new ImageIcon("src/Imagenes/Parado/Parado_1_Viaje.png"));
		JLabel parado7 = new JLabel(new ImageIcon("src/Imagenes/Parado/Parado_7_Viaje.png"));
		JLabel parado30 = new JLabel(new ImageIcon("src/Imagenes/Parado/Parado_30_Viaje.png"));

		JLabel sin_descuento1 = new JLabel(new ImageIcon("src/Imagenes/Sin_Descuento/SinDescuento_1_Viaje.png"));
		JLabel sin_descuento7 = new JLabel(new ImageIcon("src/Imagenes/Sin_Descuento/SinDescuento_7_Viaje.png"));
		JLabel sin_descuento30 = new JLabel(new ImageIcon("src/Imagenes/Sin_Descuento/SinDescuento_30_Viaje.png"));

		
		marco.setLayout(new GridLayout(2,2));
		marco.setTitle("Aplicación Movilidad");
		
		marco.add(panel_estancia);
		marco.add(panel_colectivo);
		marco.add(panel_propuesta);
		marco.add(panel_billete);
		
		marco.setSize(480, 480);
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		marco.setVisible(true);
		
		boton_verde.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				op.dias = (int) spinner.getValue();
				op.viajes = slider.getValue();
				
				if (sin_descuento.isSelected()){
					op.colectivo = 1;
				}
				if (jubilado.isSelected()){
					op.colectivo = 2;
				}
				if (parado.isSelected()){
					op.colectivo = 3;
				}
				if (discapacitado.isSelected()){
					op.colectivo = 4;
				}
				if (estudiante.isSelected()){
					op.colectivo = 5;
				}
				
				op.calculaPreciosViaje();
				op.mejorOpcion();
				texto.setText("("+op.tipodes[op.colectivo-1]+") Debería\ncoger la opción de\n"+op.opcion[op.j]+" ("+Math.round(op.precio_mas_barato * 100d)/100d+"/viajes)");

				panel_billete.removeAll();
				panel_billete.updateUI();
				
				JLabel[] tabla_imagenes_sin_descuento= new JLabel[]{sin_descuento1,sin_descuento7,sin_descuento30};
				JLabel[] tabla_imagenes_jubilado= new JLabel[]{jubilado1,jubilado7,jubilado30};
				JLabel[] tabla_imagenes_parado= new JLabel[]{parado1,parado7,parado30};
				JLabel[] tabla_imagenes_discapacitado= new JLabel[]{discapacitado1,discapacitado7,discapacitado30};
				JLabel[] tabla_imagenes_estudiante= new JLabel[]{estudiante1,estudiante7,estudiante30};
				
				JLabel[][] toda_imagenes= new JLabel[][]{tabla_imagenes_sin_descuento,tabla_imagenes_jubilado,tabla_imagenes_parado,tabla_imagenes_discapacitado,tabla_imagenes_estudiante};
				panel_billete.add(toda_imagenes[op.colectivo-1][op.j]);

			}
		});
		
		boton_rojo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				texto.setText(null);
				slider.setValue(1);
				spinner.setValue(1);
				sin_descuento.doClick();
				panel_billete.removeAll();
				panel_billete.updateUI();
			}
		});
	}
	
}
