
public class CalculadorMovilidad {

    int dias, viajes, colectivo;
    double[] tabla = {2.75, 33, 127};
    double[] descuento = {0, 50, 60, 75, 80};
    int[] bono = {1, 7, 30};
    String[] opcion = {"Billete Suelto:", "Bono para 7 dias:", "Bono para 30 dias:"};
    String[] tipodes = {"Sin descuento", "Jubilado", "Parado", "Discapacitado", "Esudiante"};
    int j=0;
    double precio_mas_barato;

    public double[] precioIlimitado7d(){

        double[] tabla7d = new double[5];
        int t = 0;

        int num = dias/bono[1];
        if (dias%bono[1] != 0){
            num++;
        }

        double num1 = (tabla[1]*num)/viajes;

        for (int j = 0; j < descuento.length; j++) {
            double precio = num1 - (num1 * (descuento[j] / 100));
            tabla7d[t] = precio;

            t++;
        }

        return tabla7d;
    }

    public double[][] calculaPreciosViaje() {
        double[] tabla_bsuelto = new double[5];
        double[] tabla30d = new double[5];

        int z=0, y=0;

        precioIlimitado7d();

        double num3=tabla[0];

        for (int b =0 ; b < descuento.length; b++) {
            
            double precio2 = num3 - (num3 * (descuento[b] / 100));
            tabla_bsuelto[z]=precio2;
            
            z++;
        }
        
        int num4 = dias/bono[2];
        if (dias%bono[2] != 0){
            num4++;
        }
        
        double num5 = (tabla[2]*num4)/viajes;

        for (int b =0 ; b < descuento.length; b++) {
            
            double precio3 = num5 - (num5 * (descuento[b] / 100));
            tabla30d[y]=precio3;

            y++;
        }
        
        double[] tablaaux;
        tablaaux =precioIlimitado7d();
        double[] tabla_sin_descuento= new double[]{tabla_bsuelto[0],tablaaux[0],tabla30d[0]};
        double[] tabla_jubilados= new double[]{tabla_bsuelto[1],tablaaux[1],tabla30d[1]};
        double[] tabla_parado= new double[]{tabla_bsuelto[2],tablaaux[2],tabla30d[2]};
        double[] tabla_discapacitado= new double[]{tabla_bsuelto[3],tablaaux[3],tabla30d[3]};
        double[] tabla_estudiante= new double[]{tabla_bsuelto[4],tablaaux[4],tabla30d[4]};

        double[][] tablaentera = new double[][]{tabla_sin_descuento,tabla_jubilados,tabla_parado,tabla_discapacitado,tabla_estudiante};

        return tablaentera;
    }

    public void mejorOpcion(){
        precio_mas_barato=999999;
        double[][] TodosLosPrecios;
        TodosLosPrecios=calculaPreciosViaje();
        for(int i=0;i<3;i++){

            if (TodosLosPrecios[colectivo-1][i]<precio_mas_barato){
                
                precio_mas_barato=TodosLosPrecios[colectivo-1][i];
                j=i;

            }
        }
    }
}